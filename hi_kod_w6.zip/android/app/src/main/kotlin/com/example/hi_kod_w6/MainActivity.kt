package com.example.hi_kod_w6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

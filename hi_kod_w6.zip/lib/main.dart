import 'dart:html';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => all_tasks(),
      child: MaterialApp(
          theme: ThemeData(
            primarySwatch: Colors.green,
          ),
          debugShowCheckedModeBanner: false,
          title: 'to_do_list',
          home: TasksList()),
    );
  }
}

class TasksList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var tasks_list_object = Provider.of<all_tasks>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('TO-DO LIST'),
      ),
      body: ListView.builder(
        itemCount: tasks_list_object.tasks_list.length,
        itemBuilder: (context, index) {
          var task = tasks_list_object.tasks_list[index];
          return TaskWidget(task: task);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => Add_Task()));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class TaskWidget extends StatelessWidget {
  task_class task;

  //constructor
  TaskWidget({required this.task});
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.window),
            title: Text(task.name),
            subtitle: Text(task.description),
            trailing: Text(" ${task.starting_date} - ${task.ending_date} "),
          ),
          ElevatedButton(
            onPressed: () {},
            child: Icon(Icons.delete),
          ),
        ],
      ),
    );
  }
}

class task_class {
  String name;
  String description;
  String starting_date;
  String ending_date;

  // Constructor
  task_class(this.name, this.description, this.starting_date, this.ending_date);
}

class all_tasks with ChangeNotifier {
  List<task_class> tasks_list = [
    task_class('Task 1', 'Till The Smoke Clears Out, ', '10/01', '10/05'),
    task_class('Task 2', 'Am I High? Perhaps, ', '10/02', '10/20'),
    task_class('Task 3', 'Imma Rip This Thing, ', '10/05', '10/10'),
    task_class('Task 4', 'Till My Bones Collapse! ', '10/04', '10/06'),
  ];

  void AddTask(task_class task) {
    tasks_list.add(task);
    notifyListeners();
  }

  void RemoveTask(task_class task) {
    tasks_list.remove(task);
    notifyListeners();
  }
}

class Add_Task extends StatefulWidget {
  @override
  State<Add_Task> createState() => _AddTaskState();
}

class _AddTaskState extends State<Add_Task> {
  TextEditingController name_controller = TextEditingController();
  TextEditingController description_controller = TextEditingController();
  TextEditingController starting_date_controller = TextEditingController();
  TextEditingController ending_date_controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    var tasks_list_object = Provider.of<all_tasks>(context);
    return Scaffold(
      appBar: AppBar(
        title: Text("Add a New Task"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            TextField(
              controller: name_controller,
              decoration: InputDecoration(
                hintText: "Name of Your Task",
              ),
            ),
            TextField(
              controller: description_controller,
              decoration: InputDecoration(
                hintText: "Details of Your Task ",
              ),
            ),
            TextField(
              controller: starting_date_controller,
              decoration: InputDecoration(
                hintText: "Starting Date of Your Task",
              ),
            ),
            TextField(
              controller: ending_date_controller,
              decoration: InputDecoration(
                hintText: "Ending Date of Your Task",
              ),
            ),
            SizedBox(
              height: 20,
            ),
            ElevatedButton(
              onPressed: () {
                var newItem = task_class(
                  name_controller.text,
                  description_controller.text,
                  starting_date_controller.text,
                  ending_date_controller.text,
                );

                tasks_list_object.AddTask(newItem);
                print(" WARNING $name_controller ");
                Navigator.pop(context);
              },
              child: Text(" ADD "),
            ),
          ],
        ),
      ),
    );
  }
}

class Remove_Task extends StatefulWidget {
  @override
  State<Remove_Task> createState() => Remove_Task_State();
}

class Remove_Task_State extends State<Remove_Task> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
    );
  }
}
